The program take the colors from an unsolved Rubik's cube through a live webcam and walks the user
through the necessary moves to solve the cube using a 2-D representation of the cube.


To run the project the user needs to have the four files, "RubiksCube.py", "ImageProcessing.py",
"RubiksGUI.py" and "SolvingEngine.py" downloaded in the same directory. To start the program
the user simply has to run the RubiksGUI.py file.

How to install the opencv library:
The user has to run the following pip command in cmd(Windows) or terminal(macOS):
pip3 install opencv-python

This file has no shortcut commands. Although the user can test the solving engine by uncommenting
the code written at the end and running the "SolvingEngine.py" file. 